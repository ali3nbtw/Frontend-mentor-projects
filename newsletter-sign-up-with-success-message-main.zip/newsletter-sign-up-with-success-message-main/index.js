function emailCheckout() {
	let emailInputValue = document.querySelector('.email-holder').value;
	let error = document.querySelector('.invalid-email-error');

	let successStateHtml = `   <img src="assets/images/icon-success.svg" alt="success-icon" class="success-icon">
   <h1>Thanks for subscribing!</h1>
   <p>A confirmation email has been sent to <b>${emailInputValue}</b>.
      Please open it and click the button inside to confirm your subscription</p>
   <button class="subscribe-btn">Dismiss message</button>`;

	if (!emailInputValue.includes('@')) {
		error.innerHTML = 'Valid email required';
	} else {
		document.body.innerHTML = successStateHtml;
	}
}
